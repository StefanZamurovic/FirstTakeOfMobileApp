import React, { useState, useEffect } from "react";
import { StyleSheet, Button, View, SafeAreaView, Text, Alert, Image, TextInput } from 'react-native';
import Constants from 'expo-constants';
import AsyncStorage from '@react-native-async-storage/async-storage';


// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const StatSheet = ({name}) => {
  
  const [catches,setCatches] = useState(0)
  const [catcheP,setCatcheP] = useState(0)
  const [drops,setDrops] = useState(0)
  const [throws,setThrows] = useState(0)
  const [hitP,setHitP] = useState(0)
  const [misses,setMisses] = useState(0)
  const [wins,setWins] = useState(0)
  const [loses,setLoses] = useState(0)
  const storeData = async (value) => {
        try {
          const jsonValue = JSON.stringify(value)
          await AsyncStorage.setItem('@mathquiz', jsonValue)
        } catch (e) {
          console.dir(e)
        }
  }

  const getData = async () => {
        try {
          const jsonValue = await AsyncStorage.getItem('@mathquiz')
          let data = null
          if (jsonValue!=null) {
            data = JSON.parse(jsonValue)
            setMisses(data.misses)
            setDrops(data.drops)
            setThrows(data.throws)
            setCatches(data.catches)
            setWins(data.wins)
            setLoses(data.loses)
          } else {
            setMisses(0)
            setDrops(0)
            setThrows(0)
            setCatches(0)
            setWins(0)
            setLoses(0)
          }
        } catch(e) {
          console.dir(e)
        }
  }

  const clearAll = async () => {
        try {
          await AsyncStorage.clear()
        } catch(e) {
          console.dir(e)
        }
  }
  return (
    <View style={{ flex: 1, alignItems: 'center', backgroundColor: "black"}}>
    <Text style={styles.text1}>{name}</Text>
    <View style={{ justifyContent: 'space-around', flexDirection: "row"}}>
    <View style={{flexDirection: "column", justifyContent: 'space-around'}}>
    <Text style={styles.text2}>Catches  </Text>
    <Text style={styles.text2}>{catches}</Text>
      <Button
        title="+1"
        color
        onPress = {() => {setCatches(catches+1),setCatcheP(catches+1/((catches+1)+drops)),storeData({catches,drops})}}
      />
      </View>
    <View style={{flexDirection: "column"}}>
    <Text style={styles.text2}>Drops</Text>
    <Text style={styles.text2}>{drops}</Text>
    <Button
        title="+1"
        color
        onPress = {() => {setDrops(drops+1),setCatcheP(catches/(catches+(drops+1))),storeData({catches,drops})}}
      />
    </View>
    </View>
    <Text style={styles.text2}>Catch: {catcheP}%</Text>
    <View style={{ justifyContent: 'space-around', flexDirection: "row"}}>
    <View style={{flexDirection: "column", justifyContent: 'space-around'}}>
    <Text style={styles.text2}>Throws  </Text>
    <Text style={styles.text2}>{throws}</Text>
      <Button
        title="+1"
        color
        onPress = {() => {setThrows(throws+1),setHitP((((throws+1) - misses)/(throws+1))*100),storeData({misses,throws})}}
      />
      </View>
    <View style={{flexDirection: "column"}}>
    <Text style={styles.text2}>Misses</Text>
    <Text style={styles.text2}>{misses}</Text>
    <Button
        title="+1"
        color
        onPress = {() => {setThrows(throws+1),setMisses(misses+1),setHitP((((throws+1) - (misses+1))/(throws+1))*100),storeData({misses,throws})}}
      />
    </View>
    </View>
    <Text style={styles.text2}>Hit: {hitP}%</Text>
    <View style={{ justifyContent: 'space-around', flexDirection: "row"}}>
    <View style={{flexDirection: "column", justifyContent: 'space-around'}}>
    <Text style={styles.text2}>Wins  </Text>
    <Text style={styles.text2}>{wins}</Text>
      <Button
        title="+1"
        color
        onPress = {() => {setThrows(wins+1),storeData({wins,loses})}}
      />
      </View>
    <View style={{flexDirection: "column"}}>
    <Text style={styles.text2}>Loses</Text>
    <Text style={styles.text2}>{loses}</Text>
    <Button
        title="+1"
        color
        onPress = {() => {setLoses(loses+1),storeData({wins,loses})}}
      />
    </View>
    </View>
    <Text style={styles.text2}>win lose ratio: {wins}/{loses}</Text>
    </View>
  );
}
const styles = StyleSheet.create({

  text1:{
    fontSize: 64,
    justifyContent: 'center',
    textAlign: 'center',
    color: 'white'
  },
  text2:{
    fontSize: 20,
    justifyContent: 'space-around',
    textAlign: 'center',
    color: 'white'
  },
  input: {
    backgroundColor: "white",
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});

export default StatSheet;









